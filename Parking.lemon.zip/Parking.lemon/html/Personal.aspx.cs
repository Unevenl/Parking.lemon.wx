﻿using LitJson;
using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WxPayAPI.example
{
    public partial class Personal : System.Web.UI.Page
    {
        /// <summary>
        /// 调用js获取收货地址时需要传入的参数
        /// 格式：json串
        /// 包含以下字段：
        ///     appid：公众号id
        ///     scope: 填写“jsapi_address”，获得编辑地址权限
        ///     signType:签名方式，目前仅支持SHA1
        ///     addrSign: 签名，由appid、url、timestamp、noncestr、accesstoken参与签名
        ///     timeStamp：时间戳
        ///     nonceStr: 随机字符串
        /// </summary>
        protected static string wxEditAddrParam2 { get; set; }
        protected string OpenID;//用户OPENID用于存cookie
        protected string UserID;//用户USERID用于存cookie

        protected void Page_Load(object sender, EventArgs e)
        {
            //页面传参
            //CARDNUMBER = Request.QueryString["CARDNUMBER"];

            //正文
            Log.Info(this.GetType().ToString(), "page load");
            if (!IsPostBack)
            {
                JsApiPay jsApiPay = new JsApiPay(this);
                try
                {
                    //调用【网页授权获取用户信息】接口获取用户的openid和access_token
                    jsApiPay.GetOpenidAndAccessToken();
                    ViewState["openid"] = jsApiPay.openid;

                    //调用【UnionID机制】获取公众号的token.详情https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1421140183
                    jsApiPay.GetAccessTokenG();
                    ViewState["access_tokenG"] = jsApiPay.access_tokenG;
                }
                catch (Exception ex)
                {
                    //Response.Write("<span style='color:#FF0000;font-size:20px'>" + "页面加载出错，请重试" + "</span>");
                    //Button1.Visible = false;
                }
            }
            //输出openID
            if (ViewState["openid"] != null)
            {
                OpenID = ViewState["openid"].ToString();
                if (ViewState["access_tokenG"] != null)
                {
                    GetUserInfo();
                }
            }
        }

        //微信信息
        public void GetUserInfo()
        {
            try
            {

                //第二种获取用户信息的方式：包括用户是否关注
                string url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=" + ViewState["access_tokenG"] + "&openid=" + ViewState["openid"] + "&lang=zh_CN";

                //请求url以获取数据
                string result = HttpService.Get(url);

                //保存json数据           
                JsonData jd = JsonMapper.ToObject(result.ToString());

                //判断关注：已关注才执行，无关注则前端页面跳转至二维码页面
                if (jd["subscribe"].ToString() == "0")
                {
                    Response.Write("<script language='javascript'>window.location='../html/LoginPage.aspx'</script>");
                }
                if (jd["subscribe"].ToString() == "1")
                {
                    string nickname = (string)jd["nickname"];
                    //NickName2.InnerText = nickname;          
                    string imgurl = (string)jd["headimgurl"];
                    //IMGURL.Src = imgurl;
                    string sex = (string)jd["sex"].ToString();
                    //string sex ="1";
                    if (sex == "1")
                    {
                        sex = "男";
                    }
                    else if (sex == "2")
                    {
                        sex = "女";
                    }
                    else

                    {
                        sex = "未知";
                    }
                    //登录BONY,获取USERID
                    Login(nickname, sex, imgurl);
                }
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }
        }

        //用户登录
        public void Login(string nickname, string sex, string imageUrl)
        {
            try
            {
                string url = "http://api.tcb.hooyoo.vip/UserSys.asmx/login?openID=" + ViewState["openid"].ToString() + "&nickname=" + nickname + "&sex=" + sex + "&imageUrl=" + imageUrl;
                string result = HttpService.Get(url);
                //获取UserID
                JsonData userinfo = JsonMapper.ToObject(result);
                string userID = userinfo["Value"]["UserID"].ToString();
                //USERID.InnerText = UserID; 
                UserID = userID;
            }
            catch (Exception ex)
            {
                Log.Error(this.GetType().ToString(), ex.ToString());
                throw new WxPayException(ex.ToString());
            }
        }

    }
}