//---------------------常规方法------------------
//写cookies
function setCookie(name, value) {
	var Days = 30;
	var exp = new Date();
	exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
	document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();
}

//读取cookies 
function getCookie(name) {
	var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
	if(arr = document.cookie.match(reg))
		return unescape(arr[2]);
	else
		return null;
}
//删除cookies 
function delCookie(name) {
	var exp = new Date();
	exp.setTime(exp.getTime() - 1);
	var cval = getCookie(name);
	if(cval != null)
		document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
}

//获取页面传参值
function GetQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}
//---------------------常规方法------------------

//---------------------自建方法------------------
//加入加载动效 
var pathname = window.location.pathname
if(pathname.indexOf("html/") != -1) {
	$("body").append('<!--加载中GIF--><img id="loading" src="../images/loading.gif" style="position: fixed;z-index: 100;width: 15%;left: 42.5%;top: 45%;" />')
}

//全局变量ajax成功数,满足则关闭loading
var ajaxNum = 0;
var ParkingCode = 18000105750501;

function addAjax(num) {
	ajaxNum++
	if(ajaxNum == num) {
		setTimeout(function() {
			$("#loading").addClass("mui-hidden")
		}, 500);
	}
	console.log("ajaxNum:" + ajaxNum)
}

//关闭加载动效果
function setLoading(type) {
	if(type == 0) {
		setTimeout(function() {
			$("#loading").addClass("mui-hidden")
		}, 500);
	} else {
		$("#loading").removeClass("mui-hidden")
	}
}

//延迟1秒关闭加载动效果
function closeLoading() {
	setTimeout(function() {
		$("#loading").addClass("mui-hidden")
	}, 1000);
}


//---------------------信息加载------------------
　