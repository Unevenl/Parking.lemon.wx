(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/ParkingSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.createParkingGet = function (_parkingCode,_parkingName,_city,_address,_describe,_x_Total,_y_Total,_f_Total,_lon,_lat, _callback) {
        $.ajax({
            url: this.url + "/createParking",
            type: "Get",
            data: {
                'parkingCode': _parkingCode,
                'parkingName': _parkingName,
                'city': _city,
                'address': _address,
                'describe': _describe,
                'x_Total': _x_Total,
                'y_Total': _y_Total,
                'f_Total': _f_Total,
                'lon':_lon,
                'lat':_lat
            },
            success: _callback
        });
    }
	Api.prototype.deleteParkingGet = function (_parkingID, _callback) {
        $.ajax({
            url: this.url + "/deleteParking",
            type: "Get",
            data: {
                'parkingID': _parkingID
            },
            success: _callback
        });
    }
	Api.prototype.getInfoByCityByPageGet = function (_city,_startIndex,_endIndex, _callback) {
        $.ajax({
            url: this.url + "/getInfoByCityByPage",
            type: "Get",
            data: {
                'city': _city,
                'startIndex':_startIndex,
                'endIndex': _endIndex
            },
            success: _callback
        });
    }
	Api.prototype.getInfoByParkingIDGet = function (_parkingID,_callback) {
        $.ajax({
            url: this.url + "/getInfoByParkingID",
            type: "Get",
            data: {
                'parkingID': _parkingID
            },
            success: _callback
        });
    }
	Api.prototype.updateParkingGet = function (_parkingID,_parkingName,_city,_address,_describe,_x_Total,_y_Total,_f_Total,_lon,_lat,_callback) {
        $.ajax({
            url: this.url + "/updateParking",
            type: "Get",
            data: {
                'parkingID': _parkingID,
                'parkingName': _parkingName,
                'city': _city,
                'address': _address,
                'describe': _describe,
                'x_Total': _x_Total,
                'y_Total': _y_Total,
                'f_Total': _f_Total,
                'lon':_lon,
                'lat':_lat
            },
            success: _callback
        });
   }
	window.ParkingSys = new Api();
})(window);