(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/CarRecordSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.createRecordGet = function (_userID,_carNo,_imageUrl,_parkingName,_parkingCode,_recordCode,_beginTime,_chargeableTime, _callback) {
        $.ajax({
            url: this.url + "/createRecord",
            type: "Get",
            data: {
                'userID': _userID,
                'carNo': _carNo,
                'imageUrl': _imageUrl,
                'parkingName': _parkingName,
                'parkingCode': _parkingCode,
                'recordCode': _recordCode,
                'beginTime': _beginTime,
                'chargeableTime': _chargeableTime
            },
            success: _callback
        });
    }
	Api.prototype.deleteRecordGet = function (_carNo,_recordCode, _callback) {
        $.ajax({
            url: this.url + "/deleteRecord",
            type: "Get",
            data: {
                'carNo': _carNo,
                'recordCode':_recordCode
            },
            success: _callback
        });
   }
    Api.prototype.getRecordByCarNoGet = function (_carNo, _startIndex,_endIndex,_callback) {
        $.ajax({
            url: this.url + "/getRecordByCarNo",
            type: "Get",
            data: {
                'carNo': _carNo,
                'startIndex': _startIndex,
                'endIndex': _endIndex
            },
            success: _callback
        });
   }
    Api.prototype.getRecordByUserIDGet = function (_userID,_startIndex,_endIndex,_callback) {
        $.ajax({
            url: this.url + "/getRecordByUserID",
            type: "Get",
            data: {
                'userID': _userID,
                'startIndex': _startIndex,
                'endIndex':_endIndex
            },
            success: _callback
        });
    }
    Api.prototype.getRecordByRecordIDGet = function (_recordID, _callback) {
        $.ajax({
            url: this.url + "/getRecordByRecordID",
            type: "Get",
            data: {
                'recordID': _recordID
            },
            success: _callback
        });
    }
	window.CarRecordSys = new Api();
})(window);