//开通月卡车
function ajaxBeMonths(carNo,nickName) {
	var gid = "54ED454B-68D4-462F-A32C-F24D6F578BD3"
	var projectGids = [gid]
	var authDevice = [1, 2]
	var nowDate = getNowDate() //2018-11-13 11:06:43
	var dateNum = getDateNum() //20181113110643 
	//参数ProjectGids填放停车场数组GID
	var dataStr = {
		"Redate": nowDate,
		"Deposit": 0,
		"IsWrite": true,
		"ProjectGids": projectGids,
		"Gid": gid,
		"ParkIssue": {
			"Redate": nowDate,
			"TokenId": carNo,
			"Token": carNo,
			"SerialNo": carNo,
			"TokenOper": 1,
			"StaffNo": dateNum,
			"StaffName": nickName,
			"OrginazitionId": "E78DFDEC-727D-4EF3-888E-D8D5AB490832",
			"Tcm": "C97611CE-C6EA-4582-9680-55934B79F9F7",
			"AccountBalance": 0,
			"BeginDate": nowDate,
			"EndDate": "2050-01-01 00:00:00",
			"AuthDevice": authDevice,
			"TokenType": 0,
			"UseModel": 1,
			"Plate": carNo,
			"OperNo": dateNum,
			"OperName": "微信自助开通",
			"Gid": gid,
			"ProjectGids": projectGids
		}
	}
    //获取日期
    function getNowDate() {
        var date = new Date();
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var hour = date.getHours()
        var day = date.getDate();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (hour >= 0 && hour <= 9) {
            hour = "0" + hour;
        }
        if (day >= 0 && day <= 9) {
            day = "0" + day;
        }
        if (minutes >= 0 && minutes <= 9) {
            minutes = "0" + minutes;
        }
        if (seconds >= 0 && seconds <= 9) {
            seconds = "0" + seconds;
        }
        var currentdate = year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
        return currentdate;
    }

    //获取日期
    function getDateNum() {
        var date = new Date();
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var hour = date.getHours()
        var day = date.getDate();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (hour >= 0 && hour <= 9) {
            hour = "0" + hour;
        }
        if (day >= 0 && day <= 9) {
            day = "0" + day;
        }
        if (minutes >= 0 && minutes <= 9) {
            minutes = "0" + minutes;
        }
        if (seconds >= 0 && seconds <= 9) {
            seconds = "0" + seconds;
        }
        var currentdate = year.toString() + month.toString() + day.toString() + hour.toString() + minutes.toString() + seconds.toString();
        return currentdate;
    }
	$.ajax({
		url: "http://115.231.2.38:60009/api/TokenService/Issue",
		type: "POST",
		data: dataStr,
        success: function (data) {
            setLoading(0)
            if (data.Model.Result == true) {
                beMonths(carNo)
            } else if (data.Model.ErrMessage == "重复注册") {
                beMonths(carNo)
            } else {
                mui.toast('开通失败!请返回重试!')
            }
           
		},
        error: function (data) {
            setLoading(0)
            //console.log(data);
            mui.toast('开通失败!请重试~')
            return false
		}
    });
    function beMonths(carNo) {
        E7Sys.beMonths(carNo, function (ret) {
            if (ret) {
                var ret = eval('(' + ret + ')')
                if (ret.StateCode == 0) {
                    setLoading(0)
                    mui.toast('开通成功!正在返回')
                    setTimeout(function () {
                        window.location.href = "../html/LoginPage.aspx"
                    }, 2000)
                } else {
                    mui.toast(ret.Value)
                }
            } else {
                mui.toast('网络错误')
            }
        })
    }
}