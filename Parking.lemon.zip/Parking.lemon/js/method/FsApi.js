(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/FsApi.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.GetParkInfoByCarNoGet = function(_parkingCode,_carNo, _callback) {
		$.ajax({
			url: this.url + "/GetParkInfoByCarNo",
			type: "Get",
			data: {
				'parkingCode': _parkingCode,
				'carNo': _carNo
			},
			success: _callback
		});
    }
    Api.prototype.ApiThirdPartyTemporaryCardPayGet = function (_amount, _actualAmount, _deductionAmount, _payStyle, _carNo, _parkingCode, _callback) {
        $.ajax({
            url: this.url + "/ApiThirdPartyTemporaryCardPay",
            type: "Get",
            data: {
                'amount': _amount,
                'actualAmount': _actualAmount,
                'deductionAmount': _deductionAmount,
                'payStyle': _payStyle,
                'carNo': _carNo,
                'parkingCode': _parkingCode
            },
            success: _callback
        });
    }
    Api.prototype.ApiThirdPartyMonthCardPayGet = function (_renewDayType, _renewDay, _payStyle, _carNo, _parkingCode, _rechargeAmt, _callback) {
        $.ajax({
            url: this.url + "/ApiThirdPartyMonthCardPay",
            type: "Get",
            data: {
                'renewDayType': _renewDayType,
                'renewDay': _renewDay,
                'payStyle': _payStyle,
                'carNo': _carNo,
                'parkingCode': _parkingCode,
                'rechargeAmt': _rechargeAmt
            },
            success: _callback
        });
    }
	window.FsApi = new Api();
})(window);