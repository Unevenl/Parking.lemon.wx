(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/CodeRecordSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.addRecordGet = function (_userID,_recordType,_recordShop, _callback) {
        $.ajax({
            url: this.url + "/addRecord",
            type: "Get",
            data: {
                'userID': _userID,
                'recordType': _recordType,
                'recordShop': _recordShop
            },
            success: _callback
        });
    }
	Api.prototype.getAllRecordGet = function (_recordType,_recordShop, _callback) {
        $.ajax({
            url: this.url + "/getAllRecord",
            type: "Get",
            data: {
                'parkingID': _parkingID
            },
            success: _callback
        });
    }
	Api.prototype.getNewRecordGet = function (_userID,_recordType,_recordShop, _callback) {
        $.ajax({
            url: this.url + "/getNewRecord",
            type: "Get",
            data: {
                'userID': _userID,
                'recordType': _recordType,
                'recordShop': _recordShop
            },
            success: _callback
        });
   }
	window.CodeRecordSys = new Api();
})(window);