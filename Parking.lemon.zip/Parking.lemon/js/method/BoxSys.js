(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.lemon.hooyoo.vip/BoxSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
Api.prototype.changePasswordGet = function(_boxID, _callback) {
		$.ajax({
			url: this.url + "/changePassword",
			type: "Get",
			data: {
				'boxID': _boxID
			},
			success: _callback
		});
	}
Api.prototype.getALLByPageGet = function(_version,_startIndex,_endIndex, _callback) {
		$.ajax({
			url: this.url + "/getALLByPage",
			type: "Get",
			data: {
				'version': _version,
				'startIndex': _startIndex,
				'endIndex': _endIndex
			},
			success: _callback
		});
	}
Api.prototype.deleteBoxGet = function(_boxID, _callback) {
		$.ajax({
			url: this.url + "/deleteBox",
			type: "Get",
			data: {
				'boxID': _boxID
			},
			success: _callback
		});
	}
Api.prototype.getBoxInfoByPasswordGet = function(_password, _callback) {
		$.ajax({
			url: this.url + "/getBoxInfoByPassword",
			type: "Get",
			data: {
				'password': _password
			},
			success: _callback
		});
	}
Api.prototype.setStateGet = function(_boxID,_state, _callback) {
		$.ajax({
			url: this.url + "/setState",
			type: "Get",
			data: {
				'boxID': _boxID,
				'state': _state
			},
			success: _callback
		});
	}
Api.prototype.updateLocationGet = function(_boxID,_lon,_lat,_address, _callback) {
		$.ajax({
			url: this.url + "/updateLocation",
			type: "Get",
			data: {
				'boxID': _boxID,
				'lon': _lon,
				'lat': _lat,
				'address':_address
			},
			success: _callback
		});
	}
Api.prototype.getBoxInfoByIDGet = function(_boxID, _callback) {
		$.ajax({
			url: this.url + "/getBoxInfoByID",
			type: "Get",
			data: {
				'boxID': _boxID
			},
			success: _callback
		});
	}
Api.prototype.createBoxGet = function(_merchantsID,_boxName,_type,_city,_version,_imageUrl,_describe, _callback) {
		$.ajax({
			url: this.url + "/createBox",
			type: "Get",
			data: {
				'merchantsID': _merchantsID,
				'boxName': _boxName,
				'type': _type,
				'city':_city,
				'version': _version,
				'imageUrl': _imageUrl,
				'describe': _describe
			},
			success: _callback
		});
	}
Api.prototype.updateBoxInfoGet = function(_boxID,_boxName,_type,_city,_version,_imageUrl,_describe, _callback) {
		$.ajax({
			url: this.url + "/updateBoxInfo",
			type: "Get",
			data: {
				'boxID': _boxID,
				'boxName': _boxName,
				'type': _type,
				'city':_city,
				'version': _version,
				'imageUrl': _imageUrl,
				'describe': _describe
			},
			success: _callback
		});
	}
	window.BoxSys = new Api();
})(window);