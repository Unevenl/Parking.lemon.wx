(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/UserSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.boundTelephoneGet = function(_userID, _telephone, _callback) {
		$.ajax({
			url: this.url + "/boundTelephone",
			type: "Get",
			data: {
				'userID': _userID,
				'telephone': _telephone
			},
			success: _callback
		});
	}
		
	Api.prototype.loginGet = function(_openID, _nickname, _sex, _imageUrl, _callback) {
		$.ajax({
			url: this.url + "/login",
			type: "Get",
			data: {
				'openID': _openID,
				'nickname': _nickname,
				'sex': _sex,
				'imageUrl': _imageUrl
			},
			success: _callback
		});
	}
	Api.prototype.getAllUserGet = function(_hi, _callback) {
		$.ajax({
			url: this.url + "/getAllUser",
			type: "Get",
			data: {
				'hi': _hi
			},
			success: _callback
		});
	}
	Api.prototype.getUserByTypeByPageGet = function(_userType,_startIndex,_endIndex, _callback) {
		$.ajax({
			url: this.url + "/getUserByTypeByPage",
			type: "Get",
			data: {
				'userType': _userType,
				'startIndex': _startIndex,
				'endIndex': _endIndex
			},
			success: _callback
		});
	}
	Api.prototype.getUserIDGet = function(_openID, _callback) {
		$.ajax({
			url: this.url + "/getUserID",
			type: "Get",
			data: {
				'openID': _openID
			},
			success: _callback
		});
	}
	Api.prototype.getUserInfoGet = function(_userID, _callback) {
		$.ajax({
			url: this.url + "/getUserInfo",
			type: "Get",
			data: {
				'userID': _userID
			},
			success: _callback
		});
	}
	Api.prototype.loginAdminGet = function(_telephone, _callback) {
		$.ajax({
			url: this.url + "/loginAdmin",
			type: "Get",
			data: {
				'telephone': _telephone
			},
			success: _callback
		});
	}
	Api.prototype.searchUserGet = function(_parameter, _callback) {
		$.ajax({
			url: this.url + "/searchUser",
			type: "Get",
			data: {
				'parameter': _parameter
			},
			success: _callback
		});
	}
	window.UserSys = new Api();
})(window);