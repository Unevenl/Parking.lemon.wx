(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/SeatSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.createSeatGet = function (_parkingID,_x_Num,_y_Num,_f_Num,_type,_seatName,_describe, _callback) {
        $.ajax({
            url: this.url + "/createSeat",
            type: "Get",
            data: {
               'parkingID': _parkingID,
               'x_Num': _x_Num,
               'y_Num': _y_Num,
               'f_Num': _f_Num,
               'type':_type,
               'seatName':_seatName,
               'describe': _describe
            },
            success: _callback
        });
    }
	Api.prototype.deleteSeatGet = function (_seatID, _callback) {
        $.ajax({
            url: this.url + "/deleteSeat",
            type: "Get",
            data: {
                'seatID': _seatID
            },
            success: _callback
        });
    }
	Api.prototype.getSeatBySeatIDGet = function (_seatID, _callback) {
        $.ajax({
            url: this.url + "/getSeatBySeatID",
            type: "Get",
            data: {
                'seatID': _seatID
            },
            success: _callback
        });
    }
	Api.prototype.getSeatByCarNoGet = function (_carNo, _callback) {
        $.ajax({
            url: this.url + "/getSeatByCarNo",
            type: "Get",
            data: {
                'carNo': _carNo
            },
            success: _callback
        });
    }
	Api.prototype.getSeatByFloorGet = function (_parkingID,_floor, _callback) {
        $.ajax({
            url: this.url + "/getSeatByFloor",
            type: "Get",
            data: {
                'parkingID': _parkingID,
                'floor': _floor
            },
            success: _callback
        });
    }
	Api.prototype.occupySeatGet = function (_carNo,_seatID,_parkingID,_userID, _callback) {
        $.ajax({
            url: this.url + "/occupySeat",
            type: "Get",
            data: {
                'carNo': _carNo,
                'seatID': _seatID,
                'parkingID':_parkingID,
                'userID':_userID
            },
            success: _callback
        });
    }
		Api.prototype.setOccupyUserIDGet = function (_seatID,_userID, _callback) {
        $.ajax({
            url: this.url + "/setOccupyUserID",
            type: "Get",
            data: {
            	'seatID': _seatID,
                'userID': _userID
            },
            success: _callback
        });
    }
	Api.prototype.getOccupyUserIDGet = function (_userID, _callback) {
        $.ajax({
            url: this.url + "/getOccupyUserID",
            type: "Get",
            data: {
            	'userID': _userID
            },
            success: _callback
        });
    }
	Api.prototype.releaseOccupyUserIDGet = function (_seatID,_userID, _callback) {
        $.ajax({
            url: this.url + "/releaseOccupyUserID",
            type: "Get",
            data: {
            	'seatID': _seatID,
                'userID': _userID
            },
            success: _callback
        });
    }
	window.SeatSys = new Api();
})(window);