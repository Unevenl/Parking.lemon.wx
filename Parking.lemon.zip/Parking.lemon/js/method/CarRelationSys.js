(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/CarRelationSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.createRelationGet = function (_userID,_carNo,_relation, _callback) {
        $.ajax({
            url: this.url + "/createRelation",
            type: "Get",
            data: {
                'userID': _userID,
                'carNo': _carNo,
                'relation':_relation
            },
            success: _callback
        });
    }
	Api.prototype.deleteRelationGet = function (_userID,_carNo, _callback) {
        $.ajax({
            url: this.url + "/deleteRelation",
            type: "Get",
            data: {
                'userID': _userID,
                'carNo': _carNo
            },
            success: _callback
        });
    }
	Api.prototype.getRelationByCarNoGet = function (_carNo, _callback) {
        $.ajax({
            url: this.url + "/getRelationByCarNo",
            type: "Get",
            data: {
                'carNo': _carNo
            },
            success: _callback
        });
    }
	Api.prototype.getRelationByUserIDGet = function (_userID, _callback) {
        $.ajax({
            url: this.url + "/getRelationByUserID",
            type: "Get",
            data: {
                'userID': _userID
            },
            success: _callback
        });
    }
	window.CarRelationSys = new Api();
})(window);