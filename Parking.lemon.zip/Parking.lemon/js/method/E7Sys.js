(function(window, undefined) {
	var Api = function() {}
    Api.prototype.url = "http://api.tcb.hooyoo.vip/E7Sys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
    Api.prototype.beMonthGet = function (_userID, _carNo, _nickName, _callback) {
        $.ajax({
            url: this.url + "/beMonth",
            type: "Get",
            data: {
                'userID': _userID,
                'carNo': _carNo,
                'nickName': _nickName
            },
            success: _callback
        });
    }
	
    window.E7Sys = new Api();
})(window);