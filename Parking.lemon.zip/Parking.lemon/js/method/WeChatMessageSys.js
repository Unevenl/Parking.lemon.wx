(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/WxMessageSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.testGet = function(_hi _callback) {
		$.ajax({
			url: this.url + "/createMessage",
			type: "Get",
			data: {
				'hi': _hi
			},
			success: _callback
		});
	}
	Api.prototype.wxDaysReportGet = function(_openID,_shopName,_shopOwner,_createAt,_color, _callback) {
		$.ajax({
			url: this.url + "/wxDaysReport",
			type: "Get",
			data: {
				'openID': _openID,
				'shopName': _shopName,
				'shopOwner': _shopOwner,
				'createAt': _createAt,
				'color': _color
			},
			success: _callback
		});
	}
	
	window.WeChatMessageSys = new Api();
})(window);