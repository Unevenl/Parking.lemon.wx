(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/ConsumeSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
    Api.prototype.consumeGet = function (_userID, _style, _goodsName, _consumeType, _number, _price, _discount, _describe, _operationPort, _operators, _carNo, _recordCode, _beginTime, _disTime, _callback) {
		$.ajax({
			url: this.url + "/consume",
			type: "Get",
			data: {
				'userID': _userID,
				'style': _style,
				'goodsName': _goodsName,
				'consumeType': _consumeType,
				'number': _number,
				'price': _price,
				'discount': _discount,
				'describe': _describe,
				'operationPort': _operationPort,
				'operators': _operators,
                'carNo': _carNo,
                'recordCode': _recordCode,
                'beginTime': _beginTime,
                'disTime':_disTime
			},
			success: _callback
		});
	}
	Api.prototype.getAllConsumeByPageGet = function(_startIndex,_endIndex, _callback) {
		$.ajax({
			url: this.url + "/getAllConsumeByPage",
			type: "Get",
			data: {
				'startIndex':_startIndex,
				'endIndex':_endIndex
			},
			success: _callback
		});
	}
	Api.prototype.getUserConsumeByPageGet = function(_userID,_startIndex,_endIndex, _callback) {
		$.ajax({
			url: this.url + "/getUserConsumeByPage",
			type: "Get",
			data: {
				'userID':_userID,
				'startIndex':_startIndex,
				'endIndex':_endIndex
			},
			success: _callback
		});
	}
	Api.prototype.getConsumeByIDGet = function(_consumeID, _callback) {
		$.ajax({
			url: this.url + "/getConsumeByID",
			type: "Get",
			data: {
				'consumeID':_consumeID
			},
			success: _callback
		});
	}
	window.ConsumeSys = new Api();
})(window);