(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/CarSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
    Api.prototype.addMonthsGet = function (_carNo, _months, _userID,_price, _callback) {
        $.ajax({
            url: this.url + "/addMonths",
            type: "Get",
            data: {
                'carNo': _carNo,
                'months': _months,
                'userID': _userID,
                'price': _price
            },
            success: _callback
        });
    }
	Api.prototype.addParkingTimeGet = function (_carNo,_totalSecond, _callback) {
        $.ajax({
            url: this.url + "/addParkingTime",
            type: "Get",
            data: {
                'carNo': _carNo,
                'totalSecond':_totalSecond
            },
            success: _callback
        });
    }
    Api.prototype.beMonthsGet = function (_carNo, _callback) {
        $.ajax({
            url: this.url + "/beMonths",
            type: "Get",
            data: {
                'carNo': _carNo
            },
            success: _callback
        });
    }
	Api.prototype.getCarByIsMonthsByPageGet = function (_isMonths,_startIndex,_endIndex, _callback) {
        $.ajax({
            url: this.url + "/getCarByIsMonthsByPage",
            type: "Get",
            data: {
                'isMonths': _isMonths,
                'startIndex':_startIndex,
                'endIndex': _endIndex
            },
            success: _callback
        });
    }
    Api.prototype.loginGet = function (_userID, _carNo, _imageUrl,_isMonths,_callback) {
        $.ajax({
            url: this.url + "/login",
            type: "Post",
            data: {
            	'userID':_userID,
                'carNo': _carNo,
                'imageUrl': _imageUrl,
                'isMonths': _isMonths
            },
            success: _callback
        });
    }
	Api.prototype.realNameGet = function (_carNo,_userID,_realName,_identityNum,_tellphone,_callback) {
        $.ajax({
            url: this.url + "/realName",
            type: "Get",
            data: {
                'carNo': _carNo,
                'userID': _userID,
                'realName': _realName,
                'identityNum': _identityNum,
                'tellphone': _tellphone
            },
            success: _callback
        });
   }
	Api.prototype.getCarByCarIDGet = function (_CarID,_callback) {
        $.ajax({
            url: this.url + "/getCarByCarID",
            type: "Get",
            data: {
                'CarID': _CarID,
            },
            success: _callback
        });
   }
	window.CarSys = new Api();
})(window);