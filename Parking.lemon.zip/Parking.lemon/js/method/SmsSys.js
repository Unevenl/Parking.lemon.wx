(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/SmsSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.checkCodeGet = function(_APPCode, _Phone,_Code, _callback) {
		$.ajax({
			url: this.url + "/checkCode",
			type: "Get",
			data: {
				'APPCode': _APPCode,
				'Phone': _Phone,
				'Code': _Code
			},
			success: _callback
		});
	}
	Api.prototype.sendMsgGet = function(_APPCode, _Phone, _Type, _callback) {
		$.ajax({
			url: this.url + "/sendMsg",
			type: "Get",
			data: {
				'APPCode': _APPCode,
				'Phone': _Phone,
				'Type': _Type
			},
			success: _callback
		});
	}
	window.SmsSys = new Api();
})(window);