(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/CouponsSys.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.getAllCouponsByTypeGet = function(_type, _callback) {
		$.ajax({
			url: this.url + "/getAllCouponsByType",
			type: "Get",
			data: {
				'type': _type
			},
			success: _callback
		});
	}
	Api.prototype.createCouponsGet = function(_title, _price, _type, _limitShop, _describe, _limitUser, _isSend, _validDays, _callback) {
		$.ajax({
			url: this.url + "/createCoupons",
			type: "Get",
			data: {
				'title': _title,
				'price': _price,
				'type': _type,
				'limitShop': _limitShop,
				'describe': _describe,
				'limitUser': _limitUser,
				'isSend': _isSend,
				'validDays': _validDays
			},
			success: _callback
		});
	}
	Api.prototype.sendCouponsGet = function(_userID, _couponsID, _callback) {
		$.ajax({
			url: this.url + "/sendCoupons",
			type: "Get",
			data: {
				'userID': _userID,
				'couponsID': _couponsID
			},
			success: _callback
		});
	}
	Api.prototype.sendCouponsToFriendsGet = function(_userID, _otherID, _codeKey, _callback) {
		$.ajax({
			url: this.url + "/sendCouponsToFriends",
			type: "Get",
			data: {
				'userID': _userID,
				'otherID': _otherID,
				'codeKey': _codeKey
			},
			success: _callback
		});
	}
	Api.prototype.getMyCouponsByUIDGet = function(_userID, _callback) {
		$.ajax({
			url: this.url + "/getMyCouponsByUID",
			type: "Get",
			data: {
				'userID': _userID
			},
			success: _callback
		});
	}
	Api.prototype.getCouponsInfoByCIDGet = function(_couponsID, _callback) {
		$.ajax({
			url: this.url + "/getCouponsInfoByCID",
			type: "Get",
			data: {
				'couponsID': _couponsID
			},
			success: _callback
		});
    }
    Api.prototype.checkCodeKeyGet = function (_userID, _codeKey, _callback) {
        $.ajax({
            url: this.url + "/checkCodeKey",
            type: "Get",
            data: {
                'userID': _userID,
                'codeKey': _codeKey
            },
            success: _callback
        });
    }
	Api.prototype.updateCouponsGet = function(_couponsID,_title, _price, _type, _limitShop, _describe, _limitUser, _isSend, _validDays, _callback) {
		$.ajax({
			url: this.url + "/updateCoupons",
			type: "Get",
			data: {
				'couponsID': _couponsID,
				'title': _title,
				'price': _price,
				'type': _type,
				'limitShop': _limitShop,
				'describe': _describe,
				'limitUser': _limitUser,
				'isSend': _isSend,
				'validDays': _validDays
			},
			success: _callback
		});
	}
	window.CouponsSys = new Api();
})(window);