(function(window, undefined) {
	var Api = function() {}
	Api.prototype.url = "http://api.tcb.hooyoo.vip/WxApi.asmx";
	Api.prototype.init = function(_url) {
		this.url = _url;
	}
	Api.prototype.GetJsapiConfigInfoGet = function(_url, _callback) {
		$.ajax({
			url: this.url + "/GetJsapiConfigInfo",
			type: "Get",
			data: {
				'url': _url
			},
			success: _callback
		});
	}
	window.WxApi = new Api();
})(window);