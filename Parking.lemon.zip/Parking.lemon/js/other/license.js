//Please provide valid license key.
//GC.Spread.Sheets.LicenseKey = "Your key";